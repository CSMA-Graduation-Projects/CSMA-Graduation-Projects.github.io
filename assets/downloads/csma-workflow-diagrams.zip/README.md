# CSMA 培养与科研流程图

13 张流程图，每张含 SVG 与可编辑 draw.io 源文件。

使用 draw.io 打开 .drawio 文件并另存副本；SVG 可在浏览器阅读，图中链接指向线上阶段指南。学校正式规则以本人适用文件为准。

- 本科科研训练流程图：[research-path.svg](research-path.svg) / [research-path.drawio](research-path.drawio)
- 本科毕业设计流程图：[bachelor-path.svg](bachelor-path.svg) / [bachelor-path.drawio](bachelor-path.drawio)
- 学科竞赛与创新实践流程图：[competition-path.svg](competition-path.svg) / [competition-path.drawio](competition-path.drawio)
- 硕士培养与学位全流程图：[master-path.svg](master-path.svg) / [master-path.drawio](master-path.drawio)
- 博士研究与学位全流程图：[doctor-path.svg](doctor-path.svg) / [doctor-path.drawio](doctor-path.drawio)
- 文献调研：从检索到研究定位：[literature.svg](literature.svg) / [literature.drawio](literature.drawio)
- 实验复现：从环境到证据：[reproduction.svg](reproduction.svg) / [reproduction.drawio](reproduction.drawio)
- 工程开发：从需求到可验收交付：[engineering.svg](engineering.svg) / [engineering.drawio](engineering.drawio)
- 论文提交：检查、评阅与答辩：[submission.svg](submission.svg) / [submission.drawio](submission.drawio)
- 日常推进：任务、反馈与下一步：[feedback.svg](feedback.svg) / [feedback.drawio](feedback.drawio)
- 归档交接：从材料到接收验收：[archiving.svg](archiving.svg) / [archiving.drawio](archiving.drawio)
- 跨校联合培养流程图：[joint-training.svg](joint-training.svg) / [joint-training.drawio](joint-training.drawio)
- 从初次联系到共同科研：[research-collaboration.svg](research-collaboration.svg) / [research-collaboration.drawio](research-collaboration.drawio)

完整说明：https://csma-graduation-projects.github.io/workflows.html

文件修改后重新生成校验清单。校验仅说明文件完整，不证明流程已获正式批准。
