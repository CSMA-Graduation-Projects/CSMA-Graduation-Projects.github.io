# CSMA Student Guide: research and study workflows

11 workflow diagrams, each with SVG and editable draw.io source files.

Open .drawio files in draw.io and save a copy before editing. Read SVG files in a browser; their links lead to online stage guides. Formal institutional rules follow the documents applicable to you.

- Undergraduate research training workflow: [research-path.svg](research-path.svg) / [research-path.drawio](research-path.drawio)
- Undergraduate capstone / thesis workflow: [bachelor-path.svg](bachelor-path.svg) / [bachelor-path.drawio](bachelor-path.drawio)
- Competitions and innovation workflow: [competition-path.svg](competition-path.svg) / [competition-path.drawio](competition-path.drawio)
- Master's research and degree workflow: [master-path.svg](master-path.svg) / [master-path.drawio](master-path.drawio)
- Doctoral research and degree pathway: [doctor-path.svg](doctor-path.svg) / [doctor-path.drawio](doctor-path.drawio)
- Literature: from search to research positioning: [literature.svg](literature.svg) / [literature.drawio](literature.drawio)
- Replication: from environment to evidence: [reproduction.svg](reproduction.svg) / [reproduction.drawio](reproduction.drawio)
- Engineering: from requirements to acceptance: [engineering.svg](engineering.svg) / [engineering.drawio](engineering.drawio)
- Thesis submission: checks, review and defense: [submission.svg](submission.svg) / [submission.drawio](submission.drawio)
- Routine work: tasks, feedback and next steps: [feedback.svg](feedback.svg) / [feedback.drawio](feedback.drawio)
- Archiving and handover: materials to acceptance: [archiving.svg](archiving.svg) / [archiving.drawio](archiving.drawio)

Full guide: https://csma-graduation-projects.github.io/en/workflows.html

Regenerate the checksum list after editing files. Checksums establish file integrity, not formal approval of a workflow.
